# 🛡️ PIPER 안전 제어 시스템 v3 가이드

## 🎯 주요 안전 기능

### 1. ✅ 무조건 홈 복귀 + 리셋 보장
**모든 종료 방법에서 안전 보장:**
- Q 키로 정상 종료
- Ctrl+C로 강제 종료
- 프로그램 크래시
- 터미널 닫기

**종료 시퀀스:**
```
1. 그리퍼 열기
2. 홈 포지션으로 이동 (필수!)
3. 3초 대기 (이동 완료 보장)
4. 대기 모드 전환
5. 리셋으로 토크 해제
6. 연결 해제
```

### 2. 🎥 좌측 카메라 최적화
**정확한 좌표 매핑:**
```python
# 카메라 → 로봇
X (좌우)  → X (전후, 반전)
  왼쪽(-) → 앞으로(+)  ✅
  오른쪽(+) → 뒤로(-)   ✅

Y (상하)  → Z (상하)
  위(+)   → 위(+)      ✅
  아래(-) → 아래(-)    ✅

Z (Depth) → Y (좌우) + Yaw (회전)
  가까이(-) → 왼쪽(-) + 왼쪽 회전(-)  ✅
  멀리(+)   → 오른쪽(+) + 오른쪽 회전(+) ✅
```

### 3. 🚧 Z축 안전 하한선
```python
# 홈 포지션 Z축 아래로 내려가지 않음
target_pos[2] = max(target_pos[2], self.home_z_limit)

# 기본값: 0.25m (250mm)
```

## 🔒 안전 메커니즘

### Signal Handler (Ctrl+C 처리)
```python
import signal

def signal_handler(self, signum, frame):
    """Ctrl+C 감지 시 안전 종료"""
    self.emergency_shutdown = True
    self.is_running = False

# 등록
signal.signal(signal.SIGINT, self.signal_handler)
signal.signal(signal.SIGTERM, self.signal_handler)
```

### atexit (프로그램 종료 보장)
```python
import atexit

def emergency_cleanup(self):
    """비상 정리 - 항상 실행됨"""
    if self.emergency_shutdown and self.piper:
        self.safe_shutdown()

# 등록
atexit.register(self.emergency_cleanup)
```

### 중복 실행 방지
```python
if self.shutdown_in_progress:
    return  # 이미 종료 중이면 중복 방지
```

## 📊 좌표 매핑 상세

### 좌측 카메라 뷰
```
    카메라 시점 (왼쪽에서 손을 봄)
    
    위(Y+)
     ↑
     │
     │   손 →  📷
     │
     └─────→ 오른쪽(X+)
    
    앞으로(Z-) / 뒤로(Z+) = Depth
```

### 로봇 뷰 (위에서 봄)
```
         앞(X+)
          ↑
          │
          │
     ←────┼────→ 오른쪽(Y+)
    왼쪽  │
          │
          ↓ 뒤(X-)
    
    위(Z+) / 아래(Z-) = 수직
    Yaw = Y축 기준 회전
```

### 매핑 테이블

| 손 동작 | 카메라 축 | 로봇 결과 | 추가 효과 |
|---------|-----------|-----------|-----------|
| 손을 **왼쪽**으로 👈 | X- | **앞**으로 이동 ⬆️ | - |
| 손을 **오른쪽**으로 👉 | X+ | **뒤**로 이동 ⬇️ | - |
| 손을 **위**로 ☝️ | Y+ | **위**로 이동 ⬆️ | - |
| 손을 **아래**로 👇 | Y- | **아래**로 이동 ⬇️ | - |
| 손을 **가까이** 🤚→📷 | Z- | **왼쪽** 이동 + **왼쪽** 회전 🔄 | Yaw - |
| 손을 **멀리** 📷←🤚 | Z+ | **오른쪽** 이동 + **오른쪽** 회전 🔄 | Yaw + |

## 🎮 실제 사용 예시

### 예시 1: 물체 집기
```
1. 캘리브레이션 (C 키)
   손을 편안한 위치에 두고

2. 제어 활성화 (SPACE)

3. 손을 왼쪽으로 이동
   → 로봇이 물체 쪽으로 전진 ⬆️

4. 손을 아래로
   → 로봇이 하강 (단, Z 하한선까지만!) ⬇️

5. 손가락 오므리기
   → 그리퍼 닫혀서 집기 ✊

6. 손을 위로
   → 로봇이 상승하면서 물체 들어올림 ⬆️
```

### 예시 2: 각도 조절하며 접근
```
1. 손을 멀리 (카메라 반대)
   → 로봇이 오른쪽 이동 + 오른쪽 회전 🔄

2. 각도가 맞으면 손 정지

3. 손을 왼쪽으로
   → 로봇이 목표물 쪽으로 전진

4. 정밀 조정 (작은 움직임)
   → 정확한 위치 맞추기
```

## 🚨 안전 종료 상세

### 정상 종료 (Q 키)
```python
1. is_running = False
2. 메인 루프 종료
3. cleanup() 호출
4. safe_shutdown() 실행
   - 그리퍼 열기
   - 홈 복귀 (3초 대기)
   - 대기 모드
   - 리셋
   - 연결 해제
```

### 비상 종료 (Ctrl+C)
```python
1. signal_handler 호출
2. emergency_shutdown = True
3. is_running = False
4. 메인 루프 즉시 종료
5. cleanup() 호출
6. safe_shutdown() 실행
   (정상 종료와 동일)
```

### 크래시 종료
```python
1. Exception 발생
2. finally 블록 실행
3. cleanup() 호출
4. safe_shutdown() 실행

또는

1. 프로그램 강제 종료
2. atexit.register() 호출
3. emergency_cleanup() 실행
4. safe_shutdown() 실행
```

## 🔧 안전 설정 조정

### Z축 하한선 변경
```python
# 기본값 (홈 포지션에서 자동 설정)
self.home_z_limit = 0.25  # 250mm

# 수동 설정
self.home_z_limit = 0.20  # 200mm (더 낮게)
self.home_z_limit = 0.30  # 300mm (더 높게)
```

### 홈 복귀 속도 조정
```python
# 느린 속도 (더 안전)
move_spd_rate_ctrl=10

# 보통 속도 (기본)
move_spd_rate_ctrl=20

# 빠른 속도
move_spd_rate_ctrl=30
```

### 홈 복귀 대기 시간
```python
# 기본값
time.sleep(3.0)  # 3초

# 느린 로봇
time.sleep(4.0)  # 4초

# 빠른 로봇
time.sleep(2.0)  # 2초
```

## 🎯 작업 공간 설정

### 기본 작업 공간
```python
self.workspace = {
    'x_min': 0.2,  'x_max': 0.5,   # 전후 (200-500mm)
    'y_min': -0.3, 'y_max': 0.3,   # 좌우 (±300mm)
    'z_min': 0.1,  'z_max': 0.5    # 상하 (100-500mm)
}

# 실제로는 Z축 하한선이 우선 (home_z_limit)
```

### 작업 공간 커스터마이징
```python
# 더 넓게
self.workspace = {
    'x_min': 0.15, 'x_max': 0.6,
    'y_min': -0.4, 'y_max': 0.4,
    'z_min': 0.05, 'z_max': 0.6
}

# 더 좁게 (안전)
self.workspace = {
    'x_min': 0.25, 'x_max': 0.45,
    'y_min': -0.2, 'y_max': 0.2,
    'z_min': 0.15, 'z_max': 0.45
}
```

## 💡 팁과 모범 사례

### 1. 항상 홈에서 시작
```bash
# 프로그램 시작 시 자동으로 홈 이동
# H 키로 언제든 홈 복귀 가능
```

### 2. Z 하한선 확인
```bash
# 프로그램 시작 시 출력되는 값 확인:
# 🛡️  Z축 안전 하한선: 0.250m

# UI에도 실시간 표시:
# Z-Limit: 0.250m
```

### 3. 천천히 움직이기
```bash
# 처음에는 작은 움직임으로 테스트
# 캘리브레이션 후 천천히 각 방향 확인
```

### 4. 비상 정지 준비
```bash
# Ctrl+C는 언제나 안전한 종료
# H 키로 즉시 홈 복귀
# SPACE 키로 제어 일시 중지
```

## 🔍 문제 해결

### Q: 홈 복귀가 실패해요
**A:** 대기 시간을 늘리세요
```python
time.sleep(5.0)  # 3초 → 5초
```

### Q: 리셋해도 토크가 안 풀려요
**A:** 리셋 후 대기 시간 증가
```python
self.piper.ResetPiper()
time.sleep(1.0)  # 0.5초 → 1.0초
```

### Q: Ctrl+C 해도 종료가 안 돼요
**A:** Signal handler 확인
```python
# __init__에서 확인:
signal.signal(signal.SIGINT, self.signal_handler)
```

### Q: 로봇이 너무 빨리 움직여요
**A:** 감도 낮추기
```python
self.pos_scale = 0.5  # 1.0 → 0.5
```

### Q: 방향이 반대로 움직여요
**A:** 좌표 매핑 확인
```python
# demo_v3_safe.py의 hand_to_robot_pose 함수에서:
robot_delta = np.array([
    -hand_delta[0],  # 부호 확인
    hand_delta[2],   # 부호 확인
    hand_delta[1]    # 부호 확인
])
```

## 📋 체크리스트

### 시작 전
- [ ] 로봇 주변 정리 (반경 1m)
- [ ] CAN 케이블 연결 확인
- [ ] 카메라가 손의 왼쪽에 위치
- [ ] 비상 정지 방법 숙지 (Ctrl+C, H, SPACE)

### 실행 중
- [ ] 캘리브레이션 완료
- [ ] Z 하한선 확인
- [ ] 천천히 움직이기
- [ ] 작업 공간 벗어나지 않기

### 종료 시
- [ ] Q 키 또는 Ctrl+C 사용
- [ ] 홈 복귀 완료 확인 (3초 대기)
- [ ] "✅ 안전 종료 완료!" 메시지 확인

## 🎓 고급 기능

### 로그 추가
```python
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 종료 시퀀스에 로그 추가
logger.info("Safe shutdown started")
logger.info("Moving to home position")
logger.info("Home position reached")
```

### 타임아웃 추가
```python
import threading

def move_with_timeout(target_joints, timeout=5.0):
    """타임아웃이 있는 이동"""
    start_time = time.time()
    self.piper.JointCtrl(*target_joints)
    
    while time.time() - start_time < timeout:
        # 위치 확인
        current = self.piper.GetArmJointMsgs()
        if self.is_at_target(current, target_joints):
            return True
        time.sleep(0.1)
    
    return False  # 타임아웃
```

## 📚 참고 자료

- `demo_v3_safe.py` - 완전한 구현
- `COORDINATE_MAPPING.md` - 좌표 변환 상세
- `piper_interface.py` - PIPER SDK 문서

---

**🛡️ 안전이 최우선입니다!**

모든 기능이 제대로 작동하는지 확인한 후 실제 작업에 사용하세요.

**버전:** v3.0  
**작성일:** 2025-11-06  
**작성자:** Claude

안전한 로봇 제어 되세요! 🤖✨
